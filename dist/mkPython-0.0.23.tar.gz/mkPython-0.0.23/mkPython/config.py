SCRIPT_PACKAGE_TYPE_STRING = 0
SCRIPT_PACKAGE_TYPE_STRING0 = 1
SCRIPT_PACKAGE_TYPE_BIGSTRING = 2


bigstring_enable = 1
script_package_type = SCRIPT_PACKAGE_TYPE_BIGSTRING
service_id_enable = 1
serial_num_len = 2
