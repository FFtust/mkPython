# import sys

# sys.path.append('\\'.join(__file__.split('\\')[:-1]))



import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
sys.path.append(curPath)

