import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
sys.path.append(curPath)


mkPython_version = "0.0.26" 

print("mkPython ", mkPython_version)
print("designed by makeblock team")