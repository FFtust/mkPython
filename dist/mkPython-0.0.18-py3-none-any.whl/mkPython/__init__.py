import sys

sys.path.append('\\'.join(__file__.split('\\')[:-1]))



